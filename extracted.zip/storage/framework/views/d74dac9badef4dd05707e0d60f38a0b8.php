<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <?php
    echo $productos;
    
        ?>
        
        <div class="container">
            <table>
                <thead>
                    <tr>Nombre</tr>
                    <tr>Var_dump</tr>
                </thead>
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <tr><td>
                        <?php echo e($producto->name); ?>

                    </td>
                    <td>
                        <?php echo e($producto); ?>

                    </td>
                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
</body>
</html>


<?php /**PATH /Users/ariel/Documents/RailCode/productos/resources/views/yeisons/index.blade.php ENDPATH**/ ?>